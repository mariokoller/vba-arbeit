<?php
echo "<html><h1>DB Verbindung</h1>";
try {
    $db = new PDO('mysql:host=db;dbname=database;charset=utf8mb4', 'admin', 'test');
    echo "Datenbank Verbindung war erfolgreich!";
} catch(PDOException $e) {
    echo "Datenbank Verbindung fehlgeschlagen!: " . $e->getMessage();
}